package projeto.estgf.ipp.pt.projeto.Voos;

public class Credenciais {

   public  String client_id;
   public  String client_secret ;
   public String grant_type ;

   public Credenciais(){
      client_id= "F6S9EKulXA3pAGduv0miIlvHVLNQeG1u";
      client_secret = "WK1CGi5OQBpeOjeo";
       grant_type ="client_credentials";
   }
}
