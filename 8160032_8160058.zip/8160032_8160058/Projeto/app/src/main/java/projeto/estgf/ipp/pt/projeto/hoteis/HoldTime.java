package projeto.estgf.ipp.pt.projeto.hoteis;


import java.io.Serializable;

public class HoldTime implements Serializable {


    private String deadline;

    public String getDeadline() {
        return deadline;
    }

    public void setDeadline(String deadline) {
        this.deadline = deadline;
    }

}
