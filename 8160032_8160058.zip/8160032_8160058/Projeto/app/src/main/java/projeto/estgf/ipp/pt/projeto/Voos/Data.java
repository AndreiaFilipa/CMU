package projeto.estgf.ipp.pt.projeto.Voos;

import java.util.List;

import projeto.estgf.ipp.pt.projeto.Voos.Datum;

public class Data {

    private List<Datum> data ;

    public List<Datum> getData() {
        return data;
    }

    public void setData(List<Datum> data) {
        this.data = data;
    }
}
