package projeto.estgf.ipp.pt.projeto.hoteis;

import java.util.List;


public class Example {


    private List<DatumHoteis> data = null;

    public List<DatumHoteis> getData() {
        return data;
    }


    public void setData(List<DatumHoteis> data) {
        this.data = data;
    }

}
