package projeto.estgf.ipp.pt.projeto;

import java.util.List;

import projeto.estgf.ipp.pt.projeto.BD.InformacoesRegisto;

public interface NotificaFimRegisto {
    public void fimPesquisa(List<InformacoesRegisto> result);
}
