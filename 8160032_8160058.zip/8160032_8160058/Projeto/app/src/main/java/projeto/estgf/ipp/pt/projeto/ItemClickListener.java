package projeto.estgf.ipp.pt.projeto;

import android.view.View;

public interface ItemClickListener {
    void onClick(View view, int position);
}
