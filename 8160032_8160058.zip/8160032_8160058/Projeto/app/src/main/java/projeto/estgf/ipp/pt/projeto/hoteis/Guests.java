package projeto.estgf.ipp.pt.projeto.hoteis;


import java.io.Serializable;

public class Guests implements Serializable {

    private Integer adults;

    public Integer getAdults() {
        return adults;
    }

    public void setAdults(Integer adults) {
        this.adults = adults;
    }

}
