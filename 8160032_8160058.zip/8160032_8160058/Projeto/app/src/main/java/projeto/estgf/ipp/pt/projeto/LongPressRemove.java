package projeto.estgf.ipp.pt.projeto;

public interface LongPressRemove {
    public void removePesquisas();
}
