package projeto.estgf.ipp.pt.projeto.Registo;

import android.support.v4.app.DialogFragment;

public interface DialogRegistoInterface {

    public void	onDialogPositiveClick();

}
