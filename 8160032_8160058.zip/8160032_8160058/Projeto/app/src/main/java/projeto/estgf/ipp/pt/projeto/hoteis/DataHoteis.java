package projeto.estgf.ipp.pt.projeto.hoteis;

import java.util.List;

public class DataHoteis {
    private List<DatumHoteis> data ;

    public List<DatumHoteis> getData() {
        return data;
    }

    public void setData(List<DatumHoteis> data) {
        this.data = data;
    }
}
