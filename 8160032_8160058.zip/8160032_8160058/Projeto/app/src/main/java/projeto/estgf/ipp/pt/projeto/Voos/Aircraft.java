package projeto.estgf.ipp.pt.projeto.Voos;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class Aircraft implements Serializable {

private String code;


public String getCode() {
return code;
}

public void setCode(String code) {
this.code = code;
}



}