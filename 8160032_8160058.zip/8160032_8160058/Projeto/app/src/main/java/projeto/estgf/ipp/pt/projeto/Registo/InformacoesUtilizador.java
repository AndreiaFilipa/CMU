package projeto.estgf.ipp.pt.projeto.Registo;

public class InformacoesUtilizador {
    public String nome;
    public String cidadeHabita;
    public String preferencias;

}
