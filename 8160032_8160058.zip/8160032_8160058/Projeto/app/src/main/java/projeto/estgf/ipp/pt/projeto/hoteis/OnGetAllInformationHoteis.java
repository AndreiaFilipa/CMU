package projeto.estgf.ipp.pt.projeto.hoteis;

import java.util.List;

import projeto.estgf.ipp.pt.projeto.BD.InformacoesHotel;

public interface OnGetAllInformationHoteis {

    public void obterInformacaoHoteis (List<InformacoesHotel> infoVoo);
}
