package projeto.estgf.ipp.pt.projeto;

import android.view.View;

public interface LongPressItem {
    void onClickLongPress(View view, int position);
}
