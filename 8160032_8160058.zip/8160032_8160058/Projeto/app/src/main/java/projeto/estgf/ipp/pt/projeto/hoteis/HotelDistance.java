package projeto.estgf.ipp.pt.projeto.hoteis;

public class HotelDistance {


    private Double distance;

    private String distanceUnit;


    public Double getDistance() {
        return distance;
    }


    public void setDistance(Double distance) {
        this.distance = distance;
    }


    public String getDistanceUnit() {
        return distanceUnit;
    }


    public void setDistanceUnit(String distanceUnit) {
        this.distanceUnit = distanceUnit;
    }

}
