package projeto.estgf.ipp.pt.projeto.Voos;

import java.util.List;

import projeto.estgf.ipp.pt.projeto.BD.InformacoesVoo;

public interface OnGetAllInformation {

    public void obterInformacao (List<InformacoesVoo> infoVoo);


}
